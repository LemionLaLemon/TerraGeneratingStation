class_name MotorOperatedValve
extends Link

var supply

func _init(from, to, Supply, max_flow = 1.0):
	source = from
	sink = to
	max_flow_kgs  = max_flow
	supply = Supply

func isOpen():
	return supply.energized()

func _capacity():
	if not supply.energized():
		return 0.0
	return super()
