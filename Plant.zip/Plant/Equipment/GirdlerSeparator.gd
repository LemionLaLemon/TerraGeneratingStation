class_name GirdlerSeparator
extends GenericContainer

var supply
var product
var effluent
var rate_kgs: float = 1.0
var recovery: float = 0.2

func _init(Elevation, Temperature, Supply, Product, Effluent, Volume = 1.0, Contents = {}):
	super(Elevation, Temperature, Volume, Contents)
	supply = Supply
	product = Product
	effluent = Effluent
	
func step(dt):
	if not supply.energized():
		return
	var got = take(Common.Materials.Water, rate_kgs * dt)
	var comp = Common.Info[Common.Materials.Water].Composition
	var d2o = got * comp[Common.Materials.D2O] * recovery
	var h2o = got * comp[Common.Materials.H2O]
	var lost = got * comp[Common.Materials.D2O] * (1.0 - recovery)
	add(Common.Materials.Water, d2o - product.add(Common.Materials.D2O, d2o))
	add(Common.Materials.Water, h2o - effluent.add(Common.Materials.H2O, h2o))
	add(Common.Materials.Water, lost - effluent.add(Common.Materials.D2O, lost))
